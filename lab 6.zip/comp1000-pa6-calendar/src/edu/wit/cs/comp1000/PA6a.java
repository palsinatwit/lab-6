package edu.wit.cs.comp1000;

import java.util.Scanner;
import edu.wit.cs.comp1000.PA6a;


public class PA6a {
		    

		    	
		    		  static final String E_YEAR = "The year must be positive!";
		    		  static final String E_DAY = "The day of January 1st must be between 0 and 6!";

		    		  
		    		  
		    		    public static boolean isLeapYear(int year) {
		    		      boolean leapyear = true;
		    		      
		    		    	if(year % 4 == 0) {
		    		    		if(year % 100 == 0) {
		    		    			if(year % 400 == 0) {
		    		    				return leapyear;
		    		    			}
		    		    		}
		    		    		else {
		    		    			return leapyear; }
		    		    		}
		    		    	return !leapyear;
		    		    	}
		    		    	
		    		    

		    		  
		    		    public static int printMonth(String month, int startDay, int numDays) {
		    		    		
		    		    	System.out.println(month);
		    		    	
		    		        int nextline = 1;
		    		        for(int j=numDays,k=1;j>0;){
		    		            if(startDay>0){
		    		            for(int i=0;i<startDay;i++){
		    		            	
		    		            	
		    		                System.out.print("   ");
		    		                nextline++;
		    		           
		    		            }
		    		            System.out.print(" ");
		    		            startDay=0;
		    		            }
		    		  
		    		            else{
		    		            	
		    		            	if(k < 10) {
		    		            		System.out.print(" ");
		    		            	}
		    		            	
		    		                System.out.print(k+" ");
		    		                nextline++;
		    		                
		    		            	
		    		            k++;
		    		            j--;
		    		            }
		    		         
		    		            if(nextline >7){
		    		            System.out.println();
		    		            System.out.print(" ");
		    		            nextline=1;
		    		    }
		    		            
		    		}
		    		        
		    		        return (nextline-1);
		    		    }
		    		   
		    		    public static void main(String[] args) {


		    		        String[] months = {"January", "February", "March", "April", "May",
		    		                "June", "July", "August", "September", "October", "November",
		    		                "December" };
		    		        int[] total_Days_In_Months = {31,28,31,30,31,30,31,31,30,31,30,31};
		    		        PA6a obj = new PA6a();
		    		        Scanner sc = new Scanner(System.in);
		    		        System.out.print("Enter the year: ");
		    		        int year = sc.nextInt();
		    		       
		    		        System.out.print("Enter the day of the week of January 1st (0=Sunday, 1=Monday, ... 6=Saturday): ");
		    		        int day_of_week = sc.nextInt();
		    		        if(year <= 0) System.out.println(E_YEAR);
		    		        else if (day_of_week <0 || day_of_week >6) System.out.println(E_DAY);
		    		        else {
		    		        if(isLeapYear(year)) {
		    		        	total_Days_In_Months[1] = 29;
		    		        }
		    		       
		    		       
		    		       
		    		        
		    		        for(int j=0;j<total_Days_In_Months.length;j++){
		    		            int endDay = day_of_week;
		    		            day_of_week = printMonth(months[j], endDay, total_Days_In_Months[j]);
		    		            System.out.println();
         }
      }	
   }
}

		
		

		
	
